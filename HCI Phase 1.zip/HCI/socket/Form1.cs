﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
namespace socket
{
    public partial class Form1 : Form
    {
        static void main(string[] args)
        {
            try
            {
                // Create a TcpClient.
                TcpClient client = new TcpClient("localhost", 12345); // Replace with the actual server address.

                // Get the network stream.
                NetworkStream stream = client.GetStream();

                // Prepare the data to send.
                string message = "Hello from C#";
                byte[] data = Encoding.ASCII.GetBytes(message);

                // Send the data to the server.
                stream.Write(data, 0, data.Length);

                Console.WriteLine("Data sent: " + message);

                // Close the client and stream.
                stream.Close();
                client.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: " + e.Message);
            }
        }
       

    }
}
