/*
	TUIO C# Demo - part of the reacTIVision project
	Copyright (c) 2005-2016 Martin Kaltenbrunner <martin@tuio.org>

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

using System;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;
using System.Collections;
using System.Threading;
using TUIO;

	public class TuioDemo : Form , TuioListener
	{
        
	    public class image
        {
		   public int x, y, w, h;
		   public Bitmap img;
        }
	    List<image> images = new List<image>();


	    public int flag = -1;
	



		private TuioClient client;
		private Dictionary<long,TuioObject> objectList;
		private Dictionary<long,TuioCursor> cursorList;
		private Dictionary<long,TuioBlob> blobList;

		public static int width, height;
		private int window_width = Screen.PrimaryScreen.Bounds.Width;
		private int window_height = Screen.PrimaryScreen.Bounds.Height;
		private int window_left = 0;
		private int window_top = 0;
		private int screen_width = Screen.PrimaryScreen.Bounds.Width;
		private int screen_height = Screen.PrimaryScreen.Bounds.Height;

		private bool fullscreen;
		private bool verbose;

		Font font = new Font("Arial", 20.0f);
		SolidBrush fntBrush = new SolidBrush(Color.Black);
		SolidBrush bgrBrush = new SolidBrush(Color.White);
		SolidBrush curBrush = new SolidBrush(Color.White);
		SolidBrush objBrush = new SolidBrush(Color.White);
		SolidBrush blbBrush = new SolidBrush(Color.White);
		Pen curPen = new Pen(new SolidBrush(Color.Blue), 1);

		public TuioDemo(int port) {
		this.WindowState = FormWindowState.Maximized;
			verbose = false;
			fullscreen = false;
			width = window_width;
			height = window_height;

			this.ClientSize = new System.Drawing.Size(width, height);
			this.Name = "TuioDemo";
			this.Text = "TuioDemo";
			
			this.Closing+=new CancelEventHandler(Form_Closing);
			this.KeyDown+=new KeyEventHandler(Form_KeyDown);

			this.SetStyle( ControlStyles.AllPaintingInWmPaint |
							ControlStyles.UserPaint |
							ControlStyles.DoubleBuffer, true);

			objectList = new Dictionary<long,TuioObject>(128);
			cursorList = new Dictionary<long,TuioCursor>(128);
			blobList   = new Dictionary<long,TuioBlob>(128);
			
			client = new TuioClient(port);
			client.addTuioListener(this);

			client.connect();
		}

		private void Form_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e) {

 			if ( e.KeyData == Keys.F) {
	 			if (fullscreen == false) {

					width = screen_width;
					height = screen_height;

					window_left = this.Left;
					window_top = this.Top;

					this.FormBorderStyle = FormBorderStyle.None;
		 			this.Left = 0;
		 			this.Top = 0;
		 			this.Width = screen_width;
		 			this.Height = screen_height;

		 			fullscreen = true;
	 			} else {

					width = window_width;
					height = window_height;

		 			this.FormBorderStyle = FormBorderStyle.Sizable;
		 			this.Left = window_left;
		 			this.Top = window_top;
		 			this.Width = window_width;
		 			this.Height = window_height;

		 			fullscreen = false;
	 			}
 			} else if ( e.KeyData == Keys.Escape) {
				this.Close();

 			} else if ( e.KeyData == Keys.V ) {
 				verbose=!verbose;
 			}

 		}

		private void Form_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			client.removeTuioListener(this);

			client.disconnect();
			System.Environment.Exit(0);
		}

		public void addTuioObject(TuioObject o) {
			lock(objectList) {
				objectList.Add(o.SessionID,o);
			} if (verbose) Console.WriteLine("add obj "+o.SymbolID+" ("+o.SessionID+") "+o.X+" "+o.Y+" "+o.Angle);
		}

		public void updateTuioObject(TuioObject o) {

			if (verbose) Console.WriteLine("set obj "+o.SymbolID+" "+o.SessionID+" "+o.X+" "+o.Y+" "+o.Angle+" "+o.MotionSpeed+" "+o.RotationSpeed+" "+o.MotionAccel+" "+o.RotationAccel);
		}

		public void removeTuioObject(TuioObject o) {
			lock(objectList) {
				objectList.Remove(o.SessionID);
			}
			if (verbose) Console.WriteLine("del obj "+o.SymbolID+" ("+o.SessionID+")");
		}

		public void addTuioCursor(TuioCursor c) {
			lock(cursorList) {
				cursorList.Add(c.SessionID,c);
			}
			if (verbose) Console.WriteLine("add cur "+c.CursorID + " ("+c.SessionID+") "+c.X+" "+c.Y);
		}

		public void updateTuioCursor(TuioCursor c) {
			if (verbose) Console.WriteLine("set cur "+c.CursorID + " ("+c.SessionID+") "+c.X+" "+c.Y+" "+c.MotionSpeed+" "+c.MotionAccel);
		}

		public void removeTuioCursor(TuioCursor c) {
			lock(cursorList) {
				cursorList.Remove(c.SessionID);
			}
			if (verbose) Console.WriteLine("del cur "+c.CursorID + " ("+c.SessionID+")");
 		}

		public void addTuioBlob(TuioBlob b) {
			lock(blobList) {
				blobList.Add(b.SessionID,b);
			}
			if (verbose) Console.WriteLine("add blb "+b.BlobID + " ("+b.SessionID+") "+b.X+" "+b.Y+" "+b.Angle+" "+b.Width+" "+b.Height+" "+b.Area);
		}

		public void updateTuioBlob(TuioBlob b) {
		
			if (verbose) Console.WriteLine("set blb "+b.BlobID + " ("+b.SessionID+") "+b.X+" "+b.Y+" "+b.Angle+" "+b.Width+" "+b.Height+" "+b.Area+" "+b.MotionSpeed+" "+b.RotationSpeed+" "+b.MotionAccel+" "+b.RotationAccel);
		}

		public void removeTuioBlob(TuioBlob b) {
			lock(blobList) {
				blobList.Remove(b.SessionID);
			}
			if (verbose) Console.WriteLine("del blb "+b.BlobID + " ("+b.SessionID+")");
		}

		public void refresh(TuioTime frameTime) {
			Invalidate();
		}

		protected override void OnPaintBackground(PaintEventArgs pevent)
		{
			// Getting the graphics object
			Graphics g = pevent.Graphics;
			g.FillRectangle(bgrBrush, new Rectangle(0,0,width,height));
		if (flag == 0)
		{
			image pnn = new image();
			pnn.x = 400;
			pnn.y = 0;
			pnn.w = window_width - 800;
			pnn.h = height - 500;
			pnn.img = new Bitmap("Tut-ankh amun.jfif");
			g.DrawImage(pnn.img, pnn.x, pnn.y, pnn.w, pnn.h);
			g.DrawString("Tut-ankh Amun", font, fntBrush, new PointF(pnn.x + 320, pnn.y + 390));
			
			g.DrawString("Tutankhamun, Tutankhamon or Tutankhamen, also known as Tutankhaten, was the antepenultimate pharaoh of the " , font, fntBrush, new PointF(pnn.x + -400, pnn.y + 440));

			g.DrawString("Eighteenth Dynasty of ancient Egypt. His death marked the end of the dynasty's royal line. Tutankhamun ascended to ", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 480));
			g.DrawString("the throne around the age of nine and reigned until his death around the age of nineteen.", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 520));
			
		}
		if (flag == 1)
		{

			image pnn = new image();
			pnn.x = 400;
			pnn.y = 0;
			pnn.w = window_width - 800;
			pnn.h = height - 500;
			pnn.img = new Bitmap("nefertari.jfif");
			g.DrawImage(pnn.img, pnn.x, pnn.y, pnn.w, pnn.h);
			g.DrawString("Nefertari", font, fntBrush, new PointF(pnn.x + 320, pnn.y + 390));
			g.DrawString("Nefertari, also known as Nefertari Meritmut, was an Egyptian queen and the first of the Great Royal Wives of Ramesses ", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 440));

			g.DrawString("the Great. She is one of the best known Egyptian queens, among such women as Cleopatra, Nefertiti,", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 480));
			g.DrawString("and Hatshepsut, and one of the most prominent not known or thought to have reigned in her own right.", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 520));

		}
		if (flag == 2)
		{
			image pnn = new image();
			pnn.x = 400;
			pnn.y = 0;
			pnn.w = window_width - 800;
			pnn.h = height - 500;
			pnn.img = new Bitmap("ramsis i.jfif");
			g.DrawImage(pnn.img, pnn.x, pnn.y, pnn.w, pnn.h);
			g.DrawString("Ramsis I", font, fntBrush, new PointF(pnn.x + 320, pnn.y + 390));
			g.DrawString("Menpehtyre Ramesses I was the founding pharaoh of ancient Egypt's 19th Dynasty. The dates for his short reign are  ", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 440));

			g.DrawString("not completely known but the timeline of late 1292�1290 BC is frequently cited as well as 1295�1294 BC.", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 480));
			
		}
		if (flag == 3)
		{
			image pnn = new image();
			pnn.x = 400;
			pnn.y = 0;
			pnn.w = window_width - 800;
			pnn.h = height - 500;
			pnn.img = new Bitmap("ramsis ii.jpg");
			g.DrawImage(pnn.img, pnn.x, pnn.y, pnn.w, pnn.h);
			g.DrawString("Ramsis II", font, fntBrush, new PointF(pnn.x + 320, pnn.y + 390));
			g.DrawString("commonly known as Ramesses the Great, was an Egyptian pharaoh. He was the third ruler of the Nineteenth Dynasty.", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 440));

			g.DrawString("Along with Thutmose III of the Eighteenth Dynasty, he is often regarded as the greatest, most celebrated,", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 480));
			g.DrawString("and most powerful pharaoh of the New Kingdom, which itself was the most powerful period of ancient Egypt.", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 520));


		}
		if (flag == 4)
		{
			image pnn = new image();
			pnn.x = 400;
			pnn.y = 0;
			pnn.w = window_width - 800;
			pnn.h = height - 500;
			pnn.img = new Bitmap("mina.jpg");
			g.DrawImage(pnn.img, pnn.x, pnn.y, pnn.w, pnn.h);
			g.DrawString("Menes", font, fntBrush, new PointF(pnn.x + 320, pnn.y + 390));
			g.DrawString("Menes was a pharaoh of the Early Dynastic Period of ancient Egypt credited by classical tradition with having ", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 440));

			g.DrawString("united Upper and Lower Egypt and as the founder of the First Dynasty.", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 480));
			
		}
		if (flag == 5)
		{
			image pnn = new image();
			pnn.x = 400;
			pnn.y = 0;
			pnn.w = window_width - 800;
			pnn.h = height - 500;
			pnn.img = new Bitmap("thutmus i.jpg");
			g.DrawImage(pnn.img, pnn.x, pnn.y, pnn.w, pnn.h);
			g.DrawString("Thutmus I", font, fntBrush, new PointF(pnn.x + 320, pnn.y + 390));
			g.DrawString("Thutmose I was the third pharaoh of the 18th Dynasty of Egypt. He received the throne after the death of the previous king,", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 440));

			g.DrawString(" Amenhotep I. During his reign, he campaigned deep into the Levant and Nubia, pushing the borders of Egypt ", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 480));
			g.DrawString("farther than ever before in each region.", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 520));


		}
		if (flag == 6)
		{
			image pnn = new image();
			pnn.x = 400;
			pnn.y = 0;
			pnn.w = window_width - 800;
			pnn.h = height - 500;
			pnn.img = new Bitmap("hatshepsut.jpg");
			g.DrawImage(pnn.img, pnn.x, pnn.y, pnn.w, pnn.h);
			g.DrawString("Hatshepsut", font, fntBrush, new PointF(pnn.x + 320, pnn.y + 390));
			g.DrawString("Hatshepsut was the Great Royal Wife of Pharaoh Thutmose II and the fifth Pharaoh of the Eighteenth Dynasty of Egypt,", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 440));

			g.DrawString("ruling first as regent, then as queen regnant from c. 1479 BC until c. 1458 BC. She was Egypt's second certain queen regnant,", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 480));
			g.DrawString(" the first being Sobekneferu/Nefrusobek in the Twelfth Dynasty.", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 520));
		}

		if (flag == 7)
		{
			image pnn = new image();
			pnn.x = 400;
			pnn.y = 0;
			pnn.w = window_width - 800;
			pnn.h = height - 500;
			pnn.img = new Bitmap("ramsis iii.jfif");
			g.DrawImage(pnn.img, pnn.x, pnn.y, pnn.w, pnn.h);
			g.DrawString("Ramsis III", font, fntBrush, new PointF(pnn.x + 320, pnn.y + 390));
			g.DrawString("Usermaatre Meryamun Ramesses III was the second Pharaoh of the Twentieth Dynasty in Ancient Egypt. He is thought", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 440));

			g.DrawString("to have reigned from 26 March 1186 to 15 April 1155 BC and is considered to be the last great monarch of the New Kingdom", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 480));
			g.DrawString("to wield any substantial authority over Egypt.", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 520));

		}
		if (flag == 8)
		{
			image pnn = new image();
			pnn.x = 400;
			pnn.y = 0;
			pnn.w = window_width - 800;
			pnn.h = height - 500;
			pnn.img = new Bitmap("rosetta stone.jfif");
			g.DrawImage(pnn.img, pnn.x, pnn.y, pnn.w, pnn.h);
			g.DrawString("Rosetta stone", font, fntBrush, new PointF(pnn.x + 320, pnn.y + 390));
			g.DrawString("The Rosetta Stone is a stele of granodiorite inscribed with three versions of a decree issued in Memphis, Egypt,", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 440));

			g.DrawString(" in 196 BC during the Ptolemaic dynasty on behalf of King Ptolemy V Epiphanes.", font, fntBrush, new PointF(pnn.x + -400, pnn.y + 480));
			

		}

		// draw the cursor path
		if (cursorList.Count > 0) {
 			 lock(cursorList) {
			 foreach (TuioCursor tcur in cursorList.Values) {
					List<TuioPoint> path = tcur.Path;
					TuioPoint current_point = path[0];

					for (int i = 0; i < path.Count; i++) {
						TuioPoint next_point = path[i];
						g.DrawLine(curPen, current_point.getScreenX(width), current_point.getScreenY(height), next_point.getScreenX(width), next_point.getScreenY(height));
						current_point = next_point;
					}
					g.FillEllipse(curBrush, current_point.getScreenX(width) - height / 100, current_point.getScreenY(height) - height / 100, height / 50, height / 50);
					g.DrawString(tcur.CursorID + "", font, fntBrush, new PointF(tcur.getScreenX(width) - 10, tcur.getScreenY(height) - 10));
				}
			}
		 }

			// draw the objects
			if (objectList.Count > 0) {
 				lock(objectList) {
					foreach (TuioObject tobj in objectList.Values) {
						int ox = tobj.getScreenX(width);
						int oy = tobj.getScreenY(height);
						int size = height / 10;

						g.TranslateTransform(ox, oy);
						g.RotateTransform((float)(tobj.Angle / Math.PI * 180.0f));
						g.TranslateTransform(-ox, -oy);
						g.TranslateTransform(ox, oy);
						g.RotateTransform(-1 * (float)(tobj.Angle / Math.PI * 180.0f));
						g.TranslateTransform(-ox, -oy);
					    
					    if(tobj.SymbolID==0)
					    {
						flag = 0;
						
					    }
					    if (tobj.SymbolID == 1)
					{
						flag = 1;

					}
					    if (tobj.SymbolID == 2)
					{
						flag = 2;

					}
						   if (tobj.SymbolID == 3)
					{
						flag = 3;

					}
						      if (tobj.SymbolID == 4)
					{
						flag = 4;

					}
							     if (tobj.SymbolID == 5)
					{
						flag = 5;

					}
								    if (tobj.SymbolID == 6)
					{
						flag = 6;

					}

					if (tobj.SymbolID == 7)
					{
						flag = 7;

					}
					if (tobj.SymbolID == 8)
					{
						flag = 8;
					}
				}
				
				}
			}

			// draw the blobs
			if (blobList.Count > 0) {
				lock(blobList) {
					foreach (TuioBlob tblb in blobList.Values) {
						int bx = tblb.getScreenX(width);
						int by = tblb.getScreenY(height);
						float bw = tblb.Width*width;
						float bh = tblb.Height*height;

						g.TranslateTransform(bx, by);
						g.RotateTransform((float)(tblb.Angle / Math.PI * 180.0f));
						g.TranslateTransform(-bx, -by);

						g.FillEllipse(blbBrush, bx - bw / 2, by - bh / 2, bw, bh);

						g.TranslateTransform(bx, by);
						g.RotateTransform(-1 * (float)(tblb.Angle / Math.PI * 180.0f));
						g.TranslateTransform(-bx, -by);
						
						g.DrawString(tblb.BlobID + "", font, fntBrush, new PointF(bx, by));
					}
				}
			}
		}

    private void InitializeComponent()
    {
            this.SuspendLayout();
            // 
            // TuioDemo
            // 
            this.ClientSize = new System.Drawing.Size(282, 253);
            this.Name = "TuioDemo";
            this.Load += new System.EventHandler(this.TuioDemo_Load);
            this.ResumeLayout(false);

    }

    private void TuioDemo_Load(object sender, EventArgs e)
    {

		fullscreen = true;
	}

    public static void Main(String[] argv) {
		
	 		int port = 0;
			switch (argv.Length) {
				case 1:
					port = int.Parse(argv[0],null);
					if(port==0) goto default;
					break;
				case 0:
					port = 3333;
					break;
				default:
					Console.WriteLine("usage: mono TuioDemo [port]");
					System.Environment.Exit(0);
					break;
			}
			
			TuioDemo app = new TuioDemo(port);
			Application.Run(app);
		}
	}
