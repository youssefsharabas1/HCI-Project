﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
    public partial class Form1 : Form
    {
        private TcpClient client;

        public Form1()
        {
            InitializeComponent();
        }

        private async void btnSend_Click(object sender, EventArgs e)
        {
            string serverIP = "localhost";
            int serverPort = 12345;

            try
            {
                // Create a TCP client socket
                client = new TcpClient();

                // Set a short timeout for testing purposes (adjust as needed)
                client.ReceiveTimeout = 5000;

                // Attempt to connect to the server
                await client.ConnectAsync(serverIP, serverPort);

                // Get the network stream from the client
                NetworkStream stream = client.GetStream();

                // Define the message
                string message = "Hello from the client!";

                // Send data to the server
                byte[] data = Encoding.UTF8.GetBytes(message);
                await stream.WriteAsync(data, 0, data.Length);

                // Receive a response from the server
                byte[] buffer = new byte[1024];
                int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                string response = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                // Display the server's response
                MessageBox.Show($"Server response: {response}", "Server Response");

                // Close the client socket
                client.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error");
            }
        }
    }
}